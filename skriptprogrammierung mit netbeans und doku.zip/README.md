skriptprogrammierung
====================

Repo des Skriptprogrammierungsgruppe 2 