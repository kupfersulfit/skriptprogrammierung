        <footer>
            Lukas Bonzelett, Alex Cremer, Thorsten Jerosch, Kirstin Schubert, Laura Spycher
        </footer>
    </body>
</html>