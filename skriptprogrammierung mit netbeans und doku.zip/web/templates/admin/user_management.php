<!-- alle Kunden ausgeben -->
<div id="tabelle"></div>