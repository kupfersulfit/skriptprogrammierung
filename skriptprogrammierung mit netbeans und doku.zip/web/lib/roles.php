<?php
    $adminEmails = array("thorsten.jerosch@rwth-aachen.de", "postvon@oben.com", "franknord@stapleware.de");
    $lieferantenEmails = array("lieferant@post.de");
?>
