var searchData=
[
  ['isconnected',['isConnected',['../classDatabaseConnector.html#a30417e69e7374ecb284861dc304624bd',1,'DatabaseConnector']]]
];
