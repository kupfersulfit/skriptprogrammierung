var searchData=
[
  ['kategorie',['Kategorie',['../classKategorie.html',1,'']]],
  ['kunde',['Kunde',['../classKunde.html',1,'']]]
];
