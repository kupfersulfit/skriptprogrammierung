var searchData=
[
  ['connect',['connect',['../classDatabaseConnector.html#a35b5a0c202be58fb17af638611fb4dc9',1,'DatabaseConnector']]]
];
