var searchData=
[
  ['loescheartikel',['loescheArtikel',['../classDatabaseModel.html#aab7854135087ea5d88e6bef29de1043f',1,'DatabaseModel']]],
  ['loeschekunde',['loescheKunde',['../classDatabaseModel.html#a65d29f2f888d41df4524da748e51e0dd',1,'DatabaseModel']]]
];
