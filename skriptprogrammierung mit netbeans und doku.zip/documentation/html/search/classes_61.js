var searchData=
[
  ['artikel',['Artikel',['../classArtikel.html',1,'']]]
];
