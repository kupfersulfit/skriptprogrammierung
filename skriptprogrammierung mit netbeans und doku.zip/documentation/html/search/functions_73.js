var searchData=
[
  ['sucheartikel',['sucheArtikel',['../classDatabaseModel.html#ac2dc51ab0cc99eef20d02b1945ef740b',1,'DatabaseModel']]]
];
