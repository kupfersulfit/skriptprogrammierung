var searchData=
[
  ['aktualisiereartikel',['aktualisiereArtikel',['../classDatabaseModel.html#a01cbad70bc79bb9f72bb92ff26682092',1,'DatabaseModel']]],
  ['aktualisierekunde',['aktualisiereKunde',['../classDatabaseModel.html#a55f3f56975923de791883e16936e891e',1,'DatabaseModel']]],
  ['artikel',['Artikel',['../classArtikel.html',1,'']]]
];
