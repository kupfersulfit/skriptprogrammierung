var searchData=
[
  ['status',['Status',['../classStatus.html',1,'']]]
];
