<nav id="subnav">
<input type="button" id="usermanagement" value="usermanagement" class="admin_tab" onclick="getUserManagement();setAdminTabActive(this.id);" />
<input type="button" id="articlemanagement" value="articlemanagement" class="admin_tab" onclick="getArticleManagement();setAdminTabActive(this.id);" />
</nav>
<div id="adminContent"></div>